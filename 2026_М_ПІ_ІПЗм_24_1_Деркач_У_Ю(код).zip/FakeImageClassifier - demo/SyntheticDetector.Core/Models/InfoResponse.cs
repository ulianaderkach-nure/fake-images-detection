using System.Text.Json.Serialization;

namespace SyntheticDetector.Core.Models;

public class InfoResponse
{
    [JsonPropertyName("modelVersion")]
    public string ModelVersion { get; set; } = string.Empty;

    [JsonPropertyName("inputSize")]
    public int InputSize { get; set; }

    [JsonPropertyName("patchSize")]
    public int PatchSize { get; set; }

    [JsonPropertyName("freqBands")]
    public int FreqBands { get; set; }

    [JsonPropertyName("normalization")]
    public string Normalization { get; set; } = string.Empty;

    [JsonPropertyName("threshold")]
    public double Threshold { get; set; }
}
