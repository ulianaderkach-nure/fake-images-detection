using System.Text.Json.Serialization;

namespace SyntheticDetector.Core.Models;

public class BatchDetectResponse
{
    [JsonPropertyName("count")]
    public int Count { get; set; }

    [JsonPropertyName("results")]
    public List<BatchItemResult> Results { get; set; } = [];

    [JsonPropertyName("modelVersion")]
    public string ModelVersion { get; set; } = string.Empty;

    [JsonPropertyName("totalMs")]
    public long TotalMs { get; set; }
}
