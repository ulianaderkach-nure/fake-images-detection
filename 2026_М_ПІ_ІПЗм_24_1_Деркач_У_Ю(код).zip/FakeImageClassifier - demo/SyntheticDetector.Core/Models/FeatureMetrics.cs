using System.Text.Json.Serialization;

namespace SyntheticDetector.Core.Models;

public class FeatureMetrics
{
    [JsonPropertyName("vitDim")]
    public int VitDim { get; set; }

    [JsonPropertyName("freqDim")]
    public int FreqDim { get; set; }
}
