using System.Text.Json.Serialization;

namespace SyntheticDetector.Core.Models;

public class BatchItemResult
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = string.Empty;

    [JsonPropertyName("isSynthetic")]
    public bool IsSynthetic { get; set; }

    [JsonPropertyName("score")]
    public double Score { get; set; }

    [JsonPropertyName("processingMs")]
    public long ProcessingMs { get; set; }
}
