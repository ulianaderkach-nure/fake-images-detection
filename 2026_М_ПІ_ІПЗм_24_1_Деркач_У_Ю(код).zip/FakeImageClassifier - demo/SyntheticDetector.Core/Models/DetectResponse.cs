using System.Text.Json.Serialization;

namespace SyntheticDetector.Core.Models;

public class DetectResponse
{
    [JsonPropertyName("isSynthetic")]
    public bool IsSynthetic { get; set; }

    [JsonPropertyName("score")]
    public double Score { get; set; }

    [JsonPropertyName("threshold")]
    public double Threshold { get; set; }

    [JsonPropertyName("modelVersion")]
    public string ModelVersion { get; set; } = string.Empty;

    [JsonPropertyName("processingMs")]
    public long ProcessingMs { get; set; }

    [JsonPropertyName("features")]
    public FeatureMetrics Features { get; set; } = new();
}
