namespace SyntheticDetector.Core.Enums;

public enum ModelType
{
    ViTBase,
    HybridCnnVit
}
