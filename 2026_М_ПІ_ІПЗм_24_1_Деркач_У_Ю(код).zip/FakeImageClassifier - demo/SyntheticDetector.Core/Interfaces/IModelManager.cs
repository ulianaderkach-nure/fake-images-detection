using SyntheticDetector.Core.Enums;
using SyntheticDetector.Core.Models;

namespace SyntheticDetector.Core.Interfaces;

public interface IModelManager
{
    InfoResponse GetModelInfo();
    void SwitchModel(ModelType newModelType);
}
