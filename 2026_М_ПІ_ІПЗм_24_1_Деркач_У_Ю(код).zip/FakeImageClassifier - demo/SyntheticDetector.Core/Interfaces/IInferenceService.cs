using SyntheticDetector.Core.Models;

namespace SyntheticDetector.Core.Interfaces;

public interface IInferenceService
{
    Task<DetectResponse> DetectAsync(Stream imageStream, string imageId = "img");
    Task<BatchDetectResponse> BatchDetectAsync(List<(Stream stream, string id)> images);
}
