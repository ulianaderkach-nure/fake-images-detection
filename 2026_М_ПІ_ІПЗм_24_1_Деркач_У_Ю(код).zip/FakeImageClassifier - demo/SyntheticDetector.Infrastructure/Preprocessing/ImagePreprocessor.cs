using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Formats;
using SixLabors.ImageSharp.PixelFormats;
using SixLabors.ImageSharp.Processing;

namespace SyntheticDetector.Infrastructure.Preprocessing;

public static class ImagePreprocessor
{
    private const int ImageSize = 224;
    private static readonly float[] Mean = [0.485f, 0.456f, 0.406f];
    private static readonly float[] Std = [0.229f, 0.224f, 0.225f];

    public static async Task<float[]> PreprocessAsync(Stream imageStream)
    {
        if (imageStream is null)
        {
            throw new ArgumentNullException(nameof(imageStream));
        }

        if (imageStream.CanSeek)
        {
            imageStream.Position = 0;
        }

        IImageFormat? format = await Image.DetectFormatAsync(imageStream);
        if (format is null)
        {
            throw new InvalidDataException("Unsupported or invalid image format.");
        }

        if (string.Equals(format.Name, "GIF", StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidDataException("GIF images are not supported.");
        }

        if (imageStream.CanSeek)
        {
            imageStream.Position = 0;
        }

        using Image<Rgb24> image = await Image.LoadAsync<Rgb24>(imageStream);
        image.Mutate(ctx => ctx.Resize(new ResizeOptions
        {
            Size = new Size(ImageSize, ImageSize),
            Mode = ResizeMode.Stretch,
            Sampler = KnownResamplers.Bicubic
        }));

        float[] input = new float[1 * 3 * ImageSize * ImageSize];
        int channelSize = ImageSize * ImageSize;

        for (int y = 0; y < ImageSize; y++)
        {
            for (int x = 0; x < ImageSize; x++)
            {
                Rgb24 pixel = image[x, y];
                int idx = y * ImageSize + x;

                float r = pixel.R / 255f;
                float g = pixel.G / 255f;
                float b = pixel.B / 255f;

                input[idx] = (r - Mean[0]) / Std[0];
                input[channelSize + idx] = (g - Mean[1]) / Std[1];
                input[(2 * channelSize) + idx] = (b - Mean[2]) / Std[2];
            }
        }

        return input;
    }
}
