namespace SyntheticDetector.Infrastructure.Options;

public sealed class ModelSettingsOptions
{
    public const string SectionName = "ModelSettings";

    public ModelArchitectureSettings ViTBase { get; set; } = new();
    public ModelArchitectureSettings HybridCnnVit { get; set; } = new();
}

public sealed class ModelArchitectureSettings
{
    public string ModelPath { get; set; } = string.Empty;
    public int InputSize { get; set; }
    public int PatchSize { get; set; }
    public int FreqBands { get; set; }
    public string Normalization { get; set; } = string.Empty;
}
