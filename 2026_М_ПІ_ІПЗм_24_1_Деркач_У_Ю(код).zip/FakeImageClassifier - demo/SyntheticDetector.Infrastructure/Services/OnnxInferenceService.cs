using System.Diagnostics;
using Microsoft.ML.OnnxRuntime;
using Microsoft.ML.OnnxRuntime.Tensors;
using SyntheticDetector.Core.Interfaces;
using SyntheticDetector.Core.Models;
using SyntheticDetector.Infrastructure.Preprocessing;

namespace SyntheticDetector.Infrastructure.Services;

public sealed class OnnxInferenceService : IInferenceService, IDisposable
{
    private readonly IModelManager _modelManager;
    private readonly object _sessionLock = new();

    private InferenceSession? _session;
    private string? _activeModelPath;

    public OnnxInferenceService(IModelManager modelManager)
    {
        _modelManager = modelManager ?? throw new ArgumentNullException(nameof(modelManager));
    }

    public async Task<DetectResponse> DetectAsync(Stream imageStream, string imageId = "img")
    {
        var stopwatch = Stopwatch.StartNew();

        float[] normalized = await ImagePreprocessor.PreprocessAsync(imageStream);
        var config = ResolveConfiguration();
        InferenceSession session = GetOrCreateSession(config.ModelPath);

        var inputTensor = new DenseTensor<float>(normalized, [1, 3, 224, 224]);
        var inputs = new List<NamedOnnxValue>
        {
            NamedOnnxValue.CreateFromTensor("input", inputTensor)
        };

        using IDisposableReadOnlyCollection<DisposableNamedOnnxValue> outputs = session.Run(inputs);
        float[] logits = outputs.First().AsEnumerable<float>().ToArray();
        double score = SoftmaxProbability(logits, config.SyntheticClassIndex);

        stopwatch.Stop();

        return new DetectResponse
        {
            IsSynthetic = score >= config.Threshold,
            Score = score,
            Threshold = config.Threshold,
            ModelVersion = config.ModelVersion,
            ProcessingMs = stopwatch.ElapsedMilliseconds,
            Features = new FeatureMetrics
            {
                VitDim = 768,
                FreqDim = 32
            }
        };
    }

    public async Task<BatchDetectResponse> BatchDetectAsync(List<(Stream stream, string id)> images)
    {
        if (images is null)
        {
            throw new ArgumentNullException(nameof(images));
        }

        var stopwatch = Stopwatch.StartNew();
        var results = new List<BatchItemResult>(images.Count);
        string modelVersion = _modelManager.GetModelInfo().ModelVersion;

        foreach ((Stream stream, string id) in images)
        {
            DetectResponse detect = await DetectAsync(stream, id);
            results.Add(new BatchItemResult
            {
                Id = id,
                IsSynthetic = detect.IsSynthetic,
                Score = detect.Score,
                ProcessingMs = detect.ProcessingMs
            });

            modelVersion = detect.ModelVersion;
        }

        stopwatch.Stop();

        return new BatchDetectResponse
        {
            Count = results.Count,
            Results = results,
            ModelVersion = modelVersion,
            TotalMs = stopwatch.ElapsedMilliseconds
        };
    }

    public void Dispose()
    {
        lock (_sessionLock)
        {
            _session?.Dispose();
            _session = null;
            _activeModelPath = null;
        }
    }

    private InferenceSession GetOrCreateSession(string modelPath)
    {
        lock (_sessionLock)
        {
            if (_session is not null &&
                string.Equals(_activeModelPath, modelPath, StringComparison.OrdinalIgnoreCase))
            {
                return _session;
            }

            _session?.Dispose();
            _session = new InferenceSession(modelPath);
            _activeModelPath = modelPath;
            return _session;
        }
    }

    private (string ModelPath, int SyntheticClassIndex, double Threshold, string ModelVersion) ResolveConfiguration()
    {
        InfoResponse info = _modelManager.GetModelInfo();
        string modelPath;
        int syntheticClassIndex;

        if (_modelManager is ModelManager manager)
        {
            modelPath = ResolveModelPath(manager.GetCurrentModelPath());
            syntheticClassIndex = manager.GetSyntheticClassIndex();
        }
        else
        {
            throw new InvalidOperationException(
                "OnnxInferenceService requires SyntheticDetector.Infrastructure.Services.ModelManager " +
                "to resolve current model path and synthetic class index.");
        }

        return (modelPath, syntheticClassIndex, info.Threshold, info.ModelVersion);
    }

    private static string ResolveModelPath(string configuredPath)
    {
        return Path.IsPathRooted(configuredPath)
            ? configuredPath
            : Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, configuredPath));
    }

    private static double SoftmaxProbability(float[] logits, int targetIndex)
    {
        if (logits.Length == 0)
        {
            throw new InvalidOperationException("Model output logits are empty.");
        }

        if (targetIndex < 0 || targetIndex >= logits.Length)
        {
            throw new ArgumentOutOfRangeException(nameof(targetIndex), "Configured synthetic class index is out of logits range.");
        }

        float maxLogit = logits.Max();
        double sum = 0d;
        var exps = new double[logits.Length];

        for (int i = 0; i < logits.Length; i++)
        {
            double exp = Math.Exp(logits[i] - maxLogit);
            exps[i] = exp;
            sum += exp;
        }

        return exps[targetIndex] / sum;
    }
}
