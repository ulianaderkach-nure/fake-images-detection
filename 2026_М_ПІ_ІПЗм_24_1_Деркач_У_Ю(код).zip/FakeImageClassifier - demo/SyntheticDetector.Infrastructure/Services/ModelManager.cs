using SyntheticDetector.Core.Enums;
using SyntheticDetector.Core.Interfaces;
using SyntheticDetector.Core.Models;
using SyntheticDetector.Infrastructure.Options;
using Microsoft.Extensions.Options;

namespace SyntheticDetector.Infrastructure.Services;

public sealed class ModelManager : IModelManager
{
    private readonly ReaderWriterLockSlim _lock = new();
    private readonly ModelSettingsOptions _modelSettings;
    private readonly Dictionary<ModelType, string> _modelPaths;

    private readonly Dictionary<ModelType, int> _syntheticClassIndices = new()
    {
        [ModelType.ViTBase] = 0,
        [ModelType.HybridCnnVit] = 0
    };

    private ModelType _currentModelType = ModelType.ViTBase;
    private double _threshold = 0.5d;

    public ModelManager(IOptions<ModelSettingsOptions> modelSettings)
    {
        _modelSettings = modelSettings?.Value
            ?? throw new ArgumentNullException(nameof(modelSettings));

        _modelPaths = new Dictionary<ModelType, string>
        {
            [ModelType.ViTBase] = _modelSettings.ViTBase.ModelPath,
            [ModelType.HybridCnnVit] = _modelSettings.HybridCnnVit.ModelPath,
        };
    }

    public InfoResponse GetModelInfo()
    {
        _lock.EnterReadLock();
        try
        {
            ModelArchitectureSettings currentSettings = GetSettingsForModel(_currentModelType);
            return new InfoResponse
            {
                ModelVersion = _currentModelType.ToString(),
                InputSize = currentSettings.InputSize,
                PatchSize = currentSettings.PatchSize,
                FreqBands = currentSettings.FreqBands,
                Normalization = currentSettings.Normalization,
                Threshold = _threshold
            };
        }
        finally
        {
            _lock.ExitReadLock();
        }
    }

    public void SwitchModel(ModelType newModelType)
    {
        _lock.EnterWriteLock();
        try
        {
            if (!_modelPaths.ContainsKey(newModelType))
            {
                throw new ArgumentOutOfRangeException(nameof(newModelType), $"No model path configured for {newModelType}.");
            }

            _currentModelType = newModelType;
        }
        finally
        {
            _lock.ExitWriteLock();
        }
    }

    public string GetCurrentModelPath()
    {
        _lock.EnterReadLock();
        try
        {
            return _modelPaths[_currentModelType];
        }
        finally
        {
            _lock.ExitReadLock();
        }
    }

    public int GetSyntheticClassIndex()
    {
        _lock.EnterReadLock();
        try
        {
            return _syntheticClassIndices[_currentModelType];
        }
        finally
        {
            _lock.ExitReadLock();
        }
    }

    public void SetThreshold(double threshold)
    {
        if (threshold is < 0 or > 1)
        {
            throw new ArgumentOutOfRangeException(nameof(threshold), "Threshold must be in range [0, 1].");
        }

        _lock.EnterWriteLock();
        try
        {
            _threshold = threshold;
        }
        finally
        {
            _lock.ExitWriteLock();
        }
    }

    private ModelArchitectureSettings GetSettingsForModel(ModelType modelType)
    {
        ModelArchitectureSettings settings = modelType switch
        {
            ModelType.ViTBase => _modelSettings.ViTBase,
            ModelType.HybridCnnVit => _modelSettings.HybridCnnVit,
            _ => throw new ArgumentOutOfRangeException(nameof(modelType), $"Unsupported model type: {modelType}.")
        };

        if (settings is null)
        {
            throw new InvalidOperationException($"Model settings for {modelType} are missing.");
        }

        if (string.IsNullOrWhiteSpace(settings.ModelPath))
        {
            throw new InvalidOperationException($"ModelPath for {modelType} must be configured.");
        }

        if (string.IsNullOrWhiteSpace(settings.Normalization))
        {
            throw new InvalidOperationException($"Normalization for {modelType} must be configured.");
        }

        return settings;
    }
}
