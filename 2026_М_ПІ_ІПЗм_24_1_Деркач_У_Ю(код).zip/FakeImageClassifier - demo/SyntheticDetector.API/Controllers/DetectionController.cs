using Microsoft.AspNetCore.Mvc;
using SyntheticDetector.Core.Interfaces;
using SyntheticDetector.Core.Models;

namespace SyntheticDetector.API.Controllers;

[ApiController]
[Route("api/detect")]
public sealed class DetectionController : ControllerBase
{
    private readonly IInferenceService _inferenceService;

    public DetectionController(IInferenceService inferenceService)
    {
        _inferenceService = inferenceService;
    }

    [HttpPost]
    [Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(DetectResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<DetectResponse>> Detect(IFormFile image)
    {
        if (image is null || image.Length == 0)
        {
            return BadRequest("A non-empty image file is required.");
        }

        try
        {
            await using Stream stream = image.OpenReadStream();
            DetectResponse response = await _inferenceService.DetectAsync(stream, image.FileName);
            return Ok(response);
        }
        catch (ArgumentException ex)
        {
            return BadRequest(ex.Message);
        }
        catch
        {
            return StatusCode(StatusCodes.Status500InternalServerError, "Unexpected error while processing image.");
        }
    }

    [HttpPost("batch")]
    [Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(BatchDetectResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<BatchDetectResponse>> DetectBatch(List<IFormFile> images)
    {
        if (images is null || images.Count == 0)
        {
            return BadRequest("At least one image file is required.");
        }

        if (images.Any(file => file.Length == 0))
        {
            return BadRequest("All image files must be non-empty.");
        }

        var streamsToDispose = new List<Stream>(images.Count);
        var inputs = new List<(Stream stream, string id)>(images.Count);

        try
        {
            foreach (IFormFile file in images)
            {
                Stream stream = file.OpenReadStream();
                streamsToDispose.Add(stream);
                inputs.Add((stream, file.FileName));
            }

            BatchDetectResponse response = await _inferenceService.BatchDetectAsync(inputs);
            return Ok(response);
        }
        catch (ArgumentException ex)
        {
            return BadRequest(ex.Message);
        }
        catch
        {
            return StatusCode(StatusCodes.Status500InternalServerError, "Unexpected error while processing batch.");
        }
        finally
        {
            foreach (Stream stream in streamsToDispose)
            {
                await stream.DisposeAsync();
            }
        }
    }

}
