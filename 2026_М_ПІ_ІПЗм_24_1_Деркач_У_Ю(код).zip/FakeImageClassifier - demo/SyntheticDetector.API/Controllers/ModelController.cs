using Microsoft.AspNetCore.Mvc;
using SyntheticDetector.Core.Enums;
using SyntheticDetector.Core.Interfaces;
using SyntheticDetector.Core.Models;

namespace SyntheticDetector.API.Controllers;

[ApiController]
[Route("api/model")]
public sealed class ModelController : ControllerBase
{
    private readonly IModelManager _modelManager;

    public ModelController(IModelManager modelManager)
    {
        _modelManager = modelManager;
    }

    [HttpGet("info")]
    [ProducesResponseType(typeof(InfoResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public ActionResult<InfoResponse> GetInfo()
    {
        try
        {
            return Ok(_modelManager.GetModelInfo());
        }
        catch
        {
            return StatusCode(StatusCodes.Status500InternalServerError, "Unexpected error while retrieving model info.");
        }
    }

    [HttpPost("switch")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public IActionResult SwitchModel([FromBody] ModelType modelType)
    {
        if (!Enum.IsDefined(modelType))
        {
            return BadRequest($"Invalid model type. Allowed values: {string.Join(", ", Enum.GetNames<ModelType>())}.");
        }

        try
        {
            _modelManager.SwitchModel(modelType);
            return Ok();
        }
        catch (ArgumentException ex)
        {
            return BadRequest(ex.Message);
        }
        catch
        {
            return StatusCode(StatusCodes.Status500InternalServerError, "Unexpected error while switching model.");
        }
    }
}
