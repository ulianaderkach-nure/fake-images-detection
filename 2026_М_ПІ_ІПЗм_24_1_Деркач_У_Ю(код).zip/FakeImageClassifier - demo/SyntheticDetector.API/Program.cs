using System.Text.Json;
using System.Text.Json.Serialization;
using SyntheticDetector.Core.Interfaces;
using SyntheticDetector.Infrastructure.Options;
using SyntheticDetector.Infrastructure.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services
    .AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
        options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
    });

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.Configure<ModelSettingsOptions>(
    builder.Configuration.GetSection(ModelSettingsOptions.SectionName));

builder.Services.AddSingleton<IModelManager, ModelManager>();
builder.Services.AddScoped<IInferenceService, OnnxInferenceService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.MapControllers();

app.Run();
